
import org.antlr.v4.runtime.tree.TerminalNode;

import java.util.HashMap;

public class SprinklesVMVisitor extends SprinklesBaseVisitor<String> implements SprinklesVisitor<String> {
    private int labelCounter = 0;

	public SprinklesVMVisitor() {
		super();
	}

	public String visitProg(SprinklesParser.ProgContext ctx) {
		StringBuilder sb = new StringBuilder();
		for(SprinklesParser.FuncContext func : ctx.func()) {
			sb.append(this.visit(func) + "\n");
		}
		return sb.toString();
	}

	public String visitFunc(SprinklesParser.FuncContext ctx) {
		StringBuilder sb = new StringBuilder();
		// Sprinkles lite doesn't support local vars, so always put "0" after func name
		sb.append("function " + ctx.ID().getText() + " 0\n");
		sb.append(this.visit(ctx.statementList()));
		if(ctx.exit() != null) { sb.append(this.visit(ctx.exit())); }
		if(ctx.ret() != null) { sb.append(this.visit(ctx.ret())); }
		return sb.toString();
	}

	public String visitStatementList(SprinklesParser.StatementListContext ctx) {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < ctx.getChildCount(); i++) {
			sb.append(this.visit(ctx.getChild(i)));
		}
		return sb.toString();
	}

	public String visitAssignmentStatement(SprinklesParser.AssignmentStatementContext ctx) {
		// full Sprinkles (not 'lite') shouldn't use static 0 but rather local #
		return (this.visit(ctx.val) + "pop static 0 // " + ctx.ID().getText() + "\n");
	}

	public String visitFuncCall(SprinklesParser.FuncCallContext ctx) {
		String funcname = ctx.ID().getText();
		return ("call " + funcname + " 0\n");
	}

    public String visitIfstatement(SprinklesParser.IfstatementContext ctx) {
        StringBuilder sb = new StringBuilder();
        if(ctx.sl2 == null) {
            sb.append(this.visit(ctx.cond));
            sb.append("not\n");
            labelCounter++;
            String label = "LABEL" + labelCounter;
            sb.append("if-goto " + label + "\n");
            sb.append(this.visit(ctx.sl));
            sb.append("label " + label + "\n");
        }
        return sb.toString();
    }

	public String visitExpr(SprinklesParser.ExprContext ctx) {
		StringBuilder sb = new StringBuilder();
		if(ctx.op != null) {
			if(ctx.op.getText().equals("!")) {
				sb.append(this.visit(ctx.right));
				sb.append("not\n");
			}
			else if(ctx.op.getText().equals("+")) {
				sb.append(this.visit(ctx.left));
				sb.append(this.visit(ctx.right));
				sb.append("add\n");
			}
			else if(ctx.op.getText().equals("-")) {
				sb.append(this.visit(ctx.left));
				sb.append(this.visit(ctx.right));
				sb.append("sub\n");
			}
            else if(ctx.op.getText().equals("==")) {
                sb.append(this.visit(ctx.left));
                sb.append(this.visit(ctx.right));
                sb.append("eq\n");
            }
		}
		else if(ctx.neg != null) {
			sb.append(this.visit(ctx.right));
			sb.append("neg\n");
		}
		else if(ctx.num != null) {
			sb.append("push constant " + ctx.num.getText() + "\n");
		}
		else if(ctx.var != null) {
			// full Sprinkles (not 'lite') shouldn't use static 0 but rather local #
			sb.append("push static 0 // " + ctx.var.getText() + "\n");
		}
		else if(ctx.funcCall() != null) {
			sb.append(this.visit(ctx.funcCall()));
		}
		else if(ctx.expr() != null) { // nested expression in parens
			for(SprinklesParser.ExprContext expr : ctx.expr()) {
				sb.append(this.visit(expr));
			}
		}
		return sb.toString();
	}

	public String visitRet(SprinklesParser.RetContext ctx) {
		StringBuilder sb = new StringBuilder();
		sb.append(this.visit(ctx.expr()));
		sb.append("return\n");
		return sb.toString();
	}

	public String visitExit(SprinklesParser.ExitContext ctx) {
		StringBuilder sb = new StringBuilder();
		sb.append(this.visit(ctx.expr()));
		sb.append("label __end__\n");
		sb.append("goto __end__\n");
		return sb.toString();
	}
}
